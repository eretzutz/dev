#!/usr/bin/env node
/** Human-friendly board inspector: node cli.mjs summary|plans|progress|followups */
import { readBoard, BOARD_FILE } from "./store.mjs";

const cmd = process.argv[2] || "summary";
const board = readBoard();

if (cmd === "path") {
  console.log(BOARD_FILE);
  process.exit(0);
}

if (cmd === "summary") {
  console.log(JSON.stringify({
    path: BOARD_FILE,
    updated_at: board.updated_at,
    plans: Object.values(board.plans).map((p) => ({
      plan_id: p.plan_id,
      title: p.title,
      status: p.status,
      steps: p.steps.map((s) => `${s.id}:${s.status}`),
    })),
    progress_events: board.progress.length,
    open_followups: board.followups.filter((f) => f.status === "open").length,
    validations: board.validations.length,
  }, null, 2));
  process.exit(0);
}

if (cmd === "raw") {
  console.log(JSON.stringify(board, null, 2));
  process.exit(0);
}

console.error("usage: node cli.mjs [summary|raw|path]");
process.exit(1);
