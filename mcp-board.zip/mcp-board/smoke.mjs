import { withBoard } from "./store.mjs";
import { spawn } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const dir = path.dirname(fileURLToPath(import.meta.url));
process.env.MCP_BOARD_PATH = path.join(dir, ".smoke-board");

// Import handlers by running tool logic through a minimal in-process path:
// we re-implement a thin call by spawning is heavy; instead exercise store + simulate.
const { default: notUsed } = await import("./store.mjs");

// Direct exercise of document flow via store API patterns matching server
const planId = await Promise.resolve(
  withBoard((board) => {
    const id = "plan_smoke1";
    board.plans[id] = {
      plan_id: id,
      title: "Smoke",
      goal: "verify board",
      steps: [{ id: "step_1", title: "write file", detail: "", owner: "orchestrator", status: "pending" }],
      acceptance: ["file exists"],
      metadata: {},
      status: "active",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    board.progress.push({
      event_id: "prog_1",
      plan_id: id,
      step_id: "step_1",
      agent: "orchestrator",
      status: "done",
      message: "ok",
      at: new Date().toISOString(),
    });
    board.validations.push({
      validation_id: "val_1",
      plan_id: id,
      passed: true,
      findings: [],
      summary: "pass",
      agent: "validator",
      at: new Date().toISOString(),
    });
    return id;
  })
);

const board = withBoard((b) => structuredClone(b));
console.log("smoke plan:", board.plans[planId].title, "status", board.plans[planId].status);
console.log("progress events:", board.progress.length);
console.log("validations:", board.validations.length);
console.log("board file OK");
