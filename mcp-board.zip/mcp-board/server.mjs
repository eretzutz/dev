#!/usr/bin/env node
/**
 * MCP Board — shared plan / progress / state / validation board for
 * multi-session Claude Code (and any MCP client).
 *
 * Transport: stdio JSON-RPC (MCP).
 * Persistence: .mcp-board/board.json (or MCP_BOARD_PATH).
 *
 * Tools:
 *   document_plan, get_plan, list_plans, update_plan_status
 *   report_progress, list_progress
 *   set_state, get_state, list_state
 *   submit_validation, list_validations
 *   request_followup, list_followups, resolve_followup
 *   get_board_summary
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { withBoard, newId, BOARD_FILE, DEFAULT_DIR } from "./store.mjs";

const SERVER_INFO = {
  name: "mcp-board",
  version: "1.0.0",
};

// ─── Tool definitions (MCP schema) ─────────────────────────────────────────

const TOOLS = [
  {
    name: "document_plan",
    description:
      "Planner: create or replace a structured implementation plan. Returns plan_id. Call this before any implementation work.",
    inputSchema: {
      type: "object",
      properties: {
        title: { type: "string", description: "Short plan title" },
        goal: { type: "string", description: "Overall goal / acceptance criteria" },
        steps: {
          type: "array",
          description: "Ordered steps",
          items: {
            type: "object",
            properties: {
              id: { type: "string", description: "Optional step id (auto if omitted)" },
              title: { type: "string" },
              detail: { type: "string" },
              owner: {
                type: "string",
                description: "Suggested role: orchestrator | subagent | human",
              },
            },
            required: ["title"],
          },
        },
        acceptance: {
          type: "array",
          items: { type: "string" },
          description: "Acceptance criteria the validator must check",
        },
        plan_id: {
          type: "string",
          description: "If set, replace an existing plan with this id",
        },
        metadata: { type: "object", description: "Arbitrary extra fields" },
      },
      required: ["title", "goal", "steps"],
    },
  },
  {
    name: "get_plan",
    description: "Load a plan by plan_id (full document including status).",
    inputSchema: {
      type: "object",
      properties: {
        plan_id: { type: "string" },
      },
      required: ["plan_id"],
    },
  },
  {
    name: "list_plans",
    description: "List plans, optionally filtered by status.",
    inputSchema: {
      type: "object",
      properties: {
        status: {
          type: "string",
          enum: ["draft", "active", "in_progress", "validating", "done", "blocked", "cancelled"],
          description: "Filter by status; omit for all",
        },
      },
    },
  },
  {
    name: "update_plan_status",
    description:
      "Set plan lifecycle status: draft | active | in_progress | validating | done | blocked | cancelled.",
    inputSchema: {
      type: "object",
      properties: {
        plan_id: { type: "string" },
        status: {
          type: "string",
          enum: ["draft", "active", "in_progress", "validating", "done", "blocked", "cancelled"],
        },
        note: { type: "string" },
      },
      required: ["plan_id", "status"],
    },
  },
  {
    name: "report_progress",
    description:
      "Orchestrator / workers: append a progress event for a plan step. Use frequently so the validator and planner can see live state.",
    inputSchema: {
      type: "object",
      properties: {
        plan_id: { type: "string" },
        step_id: { type: "string", description: "Step id from the plan" },
        agent: {
          type: "string",
          description: "Who is reporting (e.g. orchestrator, worker-auth, claude-session-2)",
        },
        status: {
          type: "string",
          enum: ["started", "working", "blocked", "done", "failed", "skipped"],
        },
        message: { type: "string", description: "Human-readable update" },
        evidence: {
          type: "string",
          description: "Paths, PR links, test output summary, commit sha, etc.",
        },
        percent: {
          type: "number",
          description: "Optional 0-100 completion for this step",
        },
      },
      required: ["plan_id", "agent", "status", "message"],
    },
  },
  {
    name: "list_progress",
    description: "List progress events for a plan (newest last). Optional step_id filter.",
    inputSchema: {
      type: "object",
      properties: {
        plan_id: { type: "string" },
        step_id: { type: "string" },
        limit: { type: "number", description: "Max events to return (default 50)" },
      },
      required: ["plan_id"],
    },
  },
  {
    name: "set_state",
    description:
      "Write a key/value into shared board state scoped to a plan (or global if plan_id omitted). Use for facts the next iteration needs.",
    inputSchema: {
      type: "object",
      properties: {
        key: { type: "string" },
        value: {
          description: "Any JSON-serializable value",
        },
        plan_id: {
          type: "string",
          description: "Scope to this plan; omit for global state",
        },
        agent: { type: "string" },
      },
      required: ["key", "value"],
    },
  },
  {
    name: "get_state",
    description: "Read a state key (plan-scoped or global).",
    inputSchema: {
      type: "object",
      properties: {
        key: { type: "string" },
        plan_id: { type: "string" },
      },
      required: ["key"],
    },
  },
  {
    name: "list_state",
    description: "List all state keys for a plan (or global).",
    inputSchema: {
      type: "object",
      properties: {
        plan_id: {
          type: "string",
          description: "Omit for global keys only",
        },
      },
    },
  },
  {
    name: "submit_validation",
    description:
      "Validator: record verification of the whole plan result. pass=false should usually be paired with request_followup.",
    inputSchema: {
      type: "object",
      properties: {
        plan_id: { type: "string" },
        passed: { type: "boolean" },
        findings: {
          type: "array",
          items: {
            type: "object",
            properties: {
              severity: {
                type: "string",
                enum: ["info", "warning", "error"],
              },
              message: { type: "string" },
              location: { type: "string" },
            },
            required: ["severity", "message"],
          },
        },
        summary: { type: "string" },
        agent: { type: "string" },
      },
      required: ["plan_id", "passed", "summary"],
    },
  },
  {
    name: "list_validations",
    description: "List validation records for a plan.",
    inputSchema: {
      type: "object",
      properties: {
        plan_id: { type: "string" },
      },
      required: ["plan_id"],
    },
  },
  {
    name: "request_followup",
    description:
      "Open a follow-up for the planner (failed validation, blocked work, new scope). Planner should list_followups and document the next plan iteration.",
    inputSchema: {
      type: "object",
      properties: {
        plan_id: { type: "string" },
        reason: { type: "string" },
        suggested_actions: {
          type: "array",
          items: { type: "string" },
        },
        priority: {
          type: "string",
          enum: ["low", "normal", "high", "urgent"],
        },
        agent: { type: "string" },
      },
      required: ["plan_id", "reason"],
    },
  },
  {
    name: "list_followups",
    description: "List follow-ups. Default: open only.",
    inputSchema: {
      type: "object",
      properties: {
        plan_id: { type: "string" },
        status: {
          type: "string",
          enum: ["open", "resolved", "all"],
        },
      },
    },
  },
  {
    name: "resolve_followup",
    description: "Mark a follow-up resolved (usually after planner documented next iteration).",
    inputSchema: {
      type: "object",
      properties: {
        followup_id: { type: "string" },
        resolution: { type: "string" },
        agent: { type: "string" },
      },
      required: ["followup_id", "resolution"],
    },
  },
  {
    name: "get_board_summary",
    description:
      "Single snapshot for any role: active plans, latest progress, open follow-ups, recent validations. Call at session start.",
    inputSchema: {
      type: "object",
      properties: {
        plan_id: {
          type: "string",
          description: "Focus on one plan; omit for all active work",
        },
      },
    },
  },
];

// ─── Tool handlers ──────────────────────────────────────────────────────────

function ok(data) {
  return {
    content: [{ type: "text", text: JSON.stringify(data, null, 2) }],
  };
}

function err(message) {
  return {
    content: [{ type: "text", text: JSON.stringify({ error: message }, null, 2) }],
    isError: true,
  };
}

function stateKey(planId, key) {
  return planId ? `plan:${planId}:${key}` : `global:${key}`;
}

const handlers = {
  document_plan(args) {
    return withBoard((board) => {
      const planId = args.plan_id || newId("plan");
      const steps = (args.steps || []).map((s, i) => ({
        id: s.id || `step_${i + 1}`,
        title: s.title,
        detail: s.detail || "",
        owner: s.owner || "orchestrator",
        status: "pending",
      }));
      const plan = {
        plan_id: planId,
        title: args.title,
        goal: args.goal,
        steps,
        acceptance: args.acceptance || [],
        metadata: args.metadata || {},
        status: board.plans[planId]?.status || "active",
        created_at: board.plans[planId]?.created_at || new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      board.plans[planId] = plan;
      return ok({ plan_id: planId, plan });
    });
  },

  get_plan(args) {
    return withBoard((board) => {
      const plan = board.plans[args.plan_id];
      if (!plan) return err(`plan not found: ${args.plan_id}`);
      return ok(plan);
    });
  },

  list_plans(args) {
    return withBoard((board) => {
      let plans = Object.values(board.plans);
      if (args.status) plans = plans.filter((p) => p.status === args.status);
      plans.sort((a, b) => (a.updated_at < b.updated_at ? 1 : -1));
      return ok({
        count: plans.length,
        plans: plans.map((p) => ({
          plan_id: p.plan_id,
          title: p.title,
          status: p.status,
          steps: p.steps.length,
          updated_at: p.updated_at,
        })),
      });
    });
  },

  update_plan_status(args) {
    return withBoard((board) => {
      const plan = board.plans[args.plan_id];
      if (!plan) return err(`plan not found: ${args.plan_id}`);
      plan.status = args.status;
      plan.updated_at = new Date().toISOString();
      if (args.note) {
        plan.status_note = args.note;
      }
      return ok({ plan_id: plan.plan_id, status: plan.status });
    });
  },

  report_progress(args) {
    return withBoard((board) => {
      if (!board.plans[args.plan_id]) return err(`plan not found: ${args.plan_id}`);
      const event = {
        event_id: newId("prog"),
        plan_id: args.plan_id,
        step_id: args.step_id || null,
        agent: args.agent,
        status: args.status,
        message: args.message,
        evidence: args.evidence || null,
        percent: args.percent ?? null,
        at: new Date().toISOString(),
      };
      board.progress.push(event);

      // Mirror step status onto the plan document
      if (args.step_id) {
        const step = board.plans[args.plan_id].steps.find((s) => s.id === args.step_id);
        if (step) {
          step.status = args.status;
          if (args.percent != null) step.percent = args.percent;
        }
      }
      if (args.status === "started" || args.status === "working") {
        if (board.plans[args.plan_id].status === "active" || board.plans[args.plan_id].status === "draft") {
          board.plans[args.plan_id].status = "in_progress";
        }
      }
      board.plans[args.plan_id].updated_at = new Date().toISOString();
      return ok(event);
    });
  },

  list_progress(args) {
    return withBoard((board) => {
      let events = board.progress.filter((e) => e.plan_id === args.plan_id);
      if (args.step_id) events = events.filter((e) => e.step_id === args.step_id);
      const limit = args.limit || 50;
      events = events.slice(-limit);
      return ok({ count: events.length, events });
    });
  },

  set_state(args) {
    return withBoard((board) => {
      const k = stateKey(args.plan_id, args.key);
      board.state[k] = {
        key: args.key,
        plan_id: args.plan_id || null,
        value: args.value,
        agent: args.agent || null,
        updated_at: new Date().toISOString(),
      };
      return ok({ key: args.key, plan_id: args.plan_id || null, stored: true });
    });
  },

  get_state(args) {
    return withBoard((board) => {
      const k = stateKey(args.plan_id, args.key);
      const entry = board.state[k];
      if (!entry) return err(`state key not found: ${args.key}`);
      return ok(entry);
    });
  },

  list_state(args) {
    return withBoard((board) => {
      const prefix = args.plan_id ? `plan:${args.plan_id}:` : "global:";
      const entries = Object.entries(board.state)
        .filter(([k]) => k.startsWith(prefix))
        .map(([, v]) => v);
      return ok({ count: entries.length, entries });
    });
  },

  submit_validation(args) {
    return withBoard((board) => {
      if (!board.plans[args.plan_id]) return err(`plan not found: ${args.plan_id}`);
      const record = {
        validation_id: newId("val"),
        plan_id: args.plan_id,
        passed: !!args.passed,
        findings: args.findings || [],
        summary: args.summary,
        agent: args.agent || "validator",
        at: new Date().toISOString(),
      };
      board.validations.push(record);
      board.plans[args.plan_id].status = args.passed ? "done" : "blocked";
      board.plans[args.plan_id].updated_at = new Date().toISOString();
      return ok(record);
    });
  },

  list_validations(args) {
    return withBoard((board) => {
      const records = board.validations.filter((v) => v.plan_id === args.plan_id);
      return ok({ count: records.length, validations: records });
    });
  },

  request_followup(args) {
    return withBoard((board) => {
      if (!board.plans[args.plan_id]) return err(`plan not found: ${args.plan_id}`);
      const fu = {
        followup_id: newId("fu"),
        plan_id: args.plan_id,
        reason: args.reason,
        suggested_actions: args.suggested_actions || [],
        priority: args.priority || "normal",
        agent: args.agent || null,
        status: "open",
        created_at: new Date().toISOString(),
        resolved_at: null,
        resolution: null,
      };
      board.followups.push(fu);
      board.plans[args.plan_id].status = "blocked";
      board.plans[args.plan_id].updated_at = new Date().toISOString();
      return ok(fu);
    });
  },

  list_followups(args) {
    return withBoard((board) => {
      let list = board.followups;
      if (args.plan_id) list = list.filter((f) => f.plan_id === args.plan_id);
      const status = args.status || "open";
      if (status !== "all") list = list.filter((f) => f.status === status);
      return ok({ count: list.length, followups: list });
    });
  },

  resolve_followup(args) {
    return withBoard((board) => {
      const fu = board.followups.find((f) => f.followup_id === args.followup_id);
      if (!fu) return err(`followup not found: ${args.followup_id}`);
      fu.status = "resolved";
      fu.resolution = args.resolution;
      fu.resolved_at = new Date().toISOString();
      fu.resolved_by = args.agent || null;
      return ok(fu);
    });
  },

  get_board_summary(args) {
    return withBoard((board) => {
      const planIds = args.plan_id
        ? [args.plan_id]
        : Object.keys(board.plans).filter((id) =>
            ["active", "in_progress", "validating", "blocked", "draft"].includes(
              board.plans[id].status
            )
          );

      const plans = planIds
        .map((id) => board.plans[id])
        .filter(Boolean)
        .map((p) => ({
          plan_id: p.plan_id,
          title: p.title,
          status: p.status,
          goal: p.goal,
          steps: p.steps.map((s) => ({
            id: s.id,
            title: s.title,
            status: s.status,
            percent: s.percent,
          })),
          acceptance: p.acceptance,
        }));

      const progress = board.progress
        .filter((e) => !args.plan_id || e.plan_id === args.plan_id)
        .slice(-20);

      const openFollowups = board.followups.filter(
        (f) =>
          f.status === "open" && (!args.plan_id || f.plan_id === args.plan_id)
      );

      const validations = board.validations
        .filter((v) => !args.plan_id || v.plan_id === args.plan_id)
        .slice(-10);

      return ok({
        board_path: BOARD_FILE,
        updated_at: board.updated_at,
        plans,
        recent_progress: progress,
        open_followups: openFollowups,
        recent_validations: validations,
      });
    });
  },
};

// ─── JSON-RPC / MCP stdio loop ──────────────────────────────────────────────

function send(msg) {
  const body = JSON.stringify(msg);
  process.stdout.write(`Content-Length: ${Buffer.byteLength(body, "utf8")}\r\n\r\n${body}`);
}

// Also accept newline-delimited JSON (some clients); primary is Content-Length framing.
let buffer = Buffer.alloc(0);

function handleMessage(msg) {
  if (msg.method === "notifications/initialized" || msg.method === "initialized") {
    return;
  }

  if (msg.method === "initialize") {
    send({
      jsonrpc: "2.0",
      id: msg.id,
      result: {
        protocolVersion: "2024-11-05",
        capabilities: { tools: {} },
        serverInfo: SERVER_INFO,
      },
    });
    return;
  }

  if (msg.method === "tools/list") {
    send({
      jsonrpc: "2.0",
      id: msg.id,
      result: { tools: TOOLS },
    });
    return;
  }

  if (msg.method === "tools/call") {
    const name = msg.params?.name;
    const args = msg.params?.arguments || {};
    const handler = handlers[name];
    if (!handler) {
      send({
        jsonrpc: "2.0",
        id: msg.id,
        result: err(`unknown tool: ${name}`),
      });
      return;
    }
    try {
      const result = handler(args);
      send({ jsonrpc: "2.0", id: msg.id, result });
    } catch (e) {
      send({
        jsonrpc: "2.0",
        id: msg.id,
        result: err(e?.message || String(e)),
      });
    }
    return;
  }

  if (msg.method === "ping") {
    send({ jsonrpc: "2.0", id: msg.id, result: {} });
    return;
  }

  // Unknown method with id → method not found
  if (msg.id != null) {
    send({
      jsonrpc: "2.0",
      id: msg.id,
      error: { code: -32601, message: `Method not found: ${msg.method}` },
    });
  }
}

function processBuffer() {
  while (true) {
    // Content-Length framing
    const headerEnd = buffer.indexOf("\r\n\r\n");
    if (headerEnd !== -1) {
      const header = buffer.slice(0, headerEnd).toString("utf8");
      const match = header.match(/Content-Length:\s*(\d+)/i);
      if (!match) {
        buffer = buffer.slice(headerEnd + 4);
        continue;
      }
      const len = parseInt(match[1], 10);
      const bodyStart = headerEnd + 4;
      if (buffer.length < bodyStart + len) return;
      const body = buffer.slice(bodyStart, bodyStart + len).toString("utf8");
      buffer = buffer.slice(bodyStart + len);
      try {
        handleMessage(JSON.parse(body));
      } catch (e) {
        process.stderr.write(`parse error: ${e.message}\n`);
      }
      continue;
    }

    // Fallback: newline-delimited JSON
    const nl = buffer.indexOf("\n");
    if (nl === -1) return;
    const line = buffer.slice(0, nl).toString("utf8").trim();
    buffer = buffer.slice(nl + 1);
    if (!line || line.startsWith("Content-Length")) continue;
    try {
      handleMessage(JSON.parse(line));
    } catch (e) {
      process.stderr.write(`parse error: ${e.message}\n`);
    }
  }
}

process.stdin.on("data", (chunk) => {
  buffer = Buffer.concat([buffer, chunk]);
  processBuffer();
});

process.stdin.on("end", () => process.exit(0));

process.stderr.write(
  `mcp-board listening on stdio (board: ${BOARD_FILE})\n`
);
