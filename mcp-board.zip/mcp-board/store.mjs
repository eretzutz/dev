/**
 * File-backed board store. Multiple MCP processes / Claude sessions share
 * the same JSON file under MCP_BOARD_PATH (default: ./.mcp-board/board.json).
 */
import fs from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";

const DEFAULT_DIR = process.env.MCP_BOARD_PATH
  ? path.resolve(process.env.MCP_BOARD_PATH)
  : path.resolve(process.cwd(), ".mcp-board");

const BOARD_FILE = path.join(DEFAULT_DIR, "board.json");
const LOCK_FILE = path.join(DEFAULT_DIR, "board.lock");

function emptyBoard() {
  return {
    version: 1,
    updated_at: new Date().toISOString(),
    plans: {},
    progress: [],
    state: {},
    validations: [],
    followups: [],
  };
}

function ensureDir() {
  fs.mkdirSync(DEFAULT_DIR, { recursive: true });
}

function acquireLock(timeoutMs = 5000) {
  ensureDir();
  const start = Date.now();
  while (true) {
    try {
      const fd = fs.openSync(LOCK_FILE, "wx");
      fs.writeFileSync(fd, String(process.pid));
      fs.closeSync(fd);
      return;
    } catch (e) {
      if (e.code !== "EEXIST") throw e;
      if (Date.now() - start > timeoutMs) {
        // Stale lock recovery
        try {
          fs.unlinkSync(LOCK_FILE);
        } catch {
          /* ignore */
        }
        continue;
      }
      // busy wait short
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 20);
    }
  }
}

function releaseLock() {
  try {
    fs.unlinkSync(LOCK_FILE);
  } catch {
    /* ignore */
  }
}

export function withBoard(fn) {
  acquireLock();
  try {
    let board = emptyBoard();
    if (fs.existsSync(BOARD_FILE)) {
      board = JSON.parse(fs.readFileSync(BOARD_FILE, "utf8"));
    }
    const result = fn(board);
    board.updated_at = new Date().toISOString();
    fs.writeFileSync(BOARD_FILE, JSON.stringify(board, null, 2));
    return result;
  } finally {
    releaseLock();
  }
}

export function readBoard() {
  return withBoard((b) => structuredClone(b));
}

export function newId(prefix = "id") {
  return `${prefix}_${randomUUID().slice(0, 8)}`;
}

export { BOARD_FILE, DEFAULT_DIR };
