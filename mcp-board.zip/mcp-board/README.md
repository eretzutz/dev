# mcp-board

Shared **plan / progress / state / validation** board for multiple Claude Code (or any MCP) sessions.

Agents do not coordinate only through chat. They call tools:

| Role | Primary tools |
|------|----------------|
| Planner | `document_plan`, `list_followups`, `resolve_followup`, `update_plan_status` |
| Orchestrator | `get_plan`, `report_progress`, `set_state`, `request_followup` |
| Validator | `list_progress`, `submit_validation`, `request_followup` |

Persistence: `MCP_BOARD_PATH/board.json` (default `./.mcp-board/board.json`), file-locked so concurrent sessions are safe on one machine.

## Install / run

No npm dependencies. Node 18+.

```bash
# from this directory
node server.mjs          # stdio MCP server (Claude Code spawns this)
node cli.mjs summary     # human view of the board
```

## Claude Code config

Project `.mcp.json` or user `~/.claude.json`:

```json
{
  "mcpServers": {
    "board": {
      "command": "node",
      "args": ["/absolute/path/to/mcp-board/server.mjs"],
      "env": {
        "MCP_BOARD_PATH": "/absolute/path/to/your-repo/.mcp-board"
      }
    }
  }
}
```

Point **every** role session at the **same** `MCP_BOARD_PATH` so they share one board.

## Suggested session setup

1. Terminal A — Planner: paste `prompts/PLANNER.md` as the system / first message.  
2. Terminal B — Orchestrator: `prompts/ORCHESTRATOR.md`.  
3. Terminal C — Validator: `prompts/VALIDATOR.md`.  

All three use the same repo (or worktrees) and the same MCP board.

## Workflow

```
Planner:  get_board_summary → document_plan → update_plan_status(active)
Orchestrator: get_plan → report_progress* → set_state* → update_plan_status(validating)
Validator: get_plan + list_progress → submit_validation
  if fail → request_followup
Planner:  list_followups → document_plan (next iteration) → resolve_followup
```

## Tool reference (short)

- **document_plan** — create/replace plan (`title`, `goal`, `steps[]`, `acceptance[]`)
- **get_plan / list_plans / update_plan_status**
- **report_progress** — step events (`started|working|blocked|done|failed|skipped`)
- **set_state / get_state / list_state** — key/value facts (plan-scoped or global)
- **submit_validation / list_validations**
- **request_followup / list_followups / resolve_followup**
- **get_board_summary** — start-of-session snapshot

## Env

| Variable | Meaning |
|----------|---------|
| `MCP_BOARD_PATH` | Directory for `board.json` (created if missing) |
